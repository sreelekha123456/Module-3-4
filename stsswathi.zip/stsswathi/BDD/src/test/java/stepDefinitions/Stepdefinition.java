package stepDefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdefinition {

	  @Given("^Enter url in browser$")
	    public void enter_url_in_browser() throws Throwable {
	       System.out.println("url");
	    }

	    @When("^the user enter First Name$")
	    public void the_user_enter_first_name() throws Throwable {
	    	System.out.println("fn");
	    }

	    @Then("^New Customer registration should be successful$")
	    public void new_customer_registration_should_be_successful() throws Throwable {
	    	System.out.println("sucess");
	    }

	    @And("^Click on Continue in New Customer$")
	    public void click_on_continue_in_new_customer() throws Throwable {
	    	System.out.println("newcustomer");
	    }

	    @And("^enter Last Name$")
	    public void enter_last_name() throws Throwable {
	    	System.out.println("ln");
	    }

	    @And("^enter valid email address$")
	    public void enter_valid_email_address() throws Throwable {
	    	System.out.println("adress");
	    }

	    @And("^enter valid telephone number$")
	    public void enter_valid_telephone_number() throws Throwable {
	    	System.out.println("number");
	    }

	    @And("^enter password$")
	    public void enter_password() throws Throwable {
	    	System.out.println("pswd");
	    }

	    @And("^enter confirm password$")
	    public void enter_confirm_password() throws Throwable {
	    	System.out.println("confpswd");
	    }

	    @And("^click on yes in Newsletter$")
	    public void click_on_yes_in_newsletter() throws Throwable {
	    	System.out.println("newsletter");
	    }

	    @And("^click on privacy policy$")
	    public void click_on_privacy_policy() throws Throwable {
	    	System.out.println("privacypolicy");
	    }

	    @And("^click on continue in Register Account$")
	    public void click_on_continue_in_register_account() throws Throwable {
	    	System.out.println("registered");
	    }
	    @Given("^Invoke the browser$")
	    public void invoke_the_browser() throws Throwable {
	    	System.out.println("before all scenarios");
	    }
	    

    @When("^user enter valid email and password$")
    public void user_enter_valid_email_and_password() throws Throwable {
    	System.out.println("valid email and pswd");
    }

    @Then("^click on check out$")
    public void click_on_check_out() throws Throwable {
    	System.out.println("checkout");
    }

    @And("^click on login$")
    public void click_on_login() throws Throwable {
    	System.out.println("login");
    }

    @And("^click on laptops&notepads$")
    public void click_on_laptopsnotepads() throws Throwable {
    	System.out.println("see all laptops");
    }

    @And("^click on add to cart$")
    public void click_on_add_to_cart() throws Throwable {
    	System.out.println("add to cart");
    }
	     
	    
}
