package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RetrivePwd
{
	WebDriver driver;
	public RetrivePwd(WebDriver driver)                                   
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	@FindBy(xpath=".//*[@id='header']/div[2]/div/div/nav/div[1]/a")
	@CacheLookup 
    WebElement loginrtv;
	
	@FindBy(xpath=".//*[@id='login_form']/div/p[1]/a")
	@CacheLookup 
    WebElement forgotpwd;
	
	@FindBy(id="email")
	@CacheLookup 
    WebElement emailrvt;
	
	@FindBy(xpath=".//*[@id='form_forgotpassword']/fieldset/p/button")
	@CacheLookup 
    WebElement retrievebtn;
	
	@FindBy(xpath=".//*[@id='center_column']/ul/li/a/span")
	@CacheLookup 
    WebElement backtohome;
	
	public WebElement LoginRtv()
	{
		return loginrtv;
	}
	
	public WebElement Forgotpwd()
	{
		return forgotpwd;
	}
	public WebElement EmailRvt()
	{
		return emailrvt;
	}
	public WebElement RetrieveBtn()
	{
		return retrievebtn;
	}
	public WebElement BackHome()
	{
		return backtohome;
	}
}
