package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Alerts {
	WebDriver driver;
	public Alerts(WebDriver driver)                                   
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
}
	@FindBy(className="login")
	@CacheLookup 
    WebElement loginerr;
	
	@FindBy(id="SubmitLogin")
	@CacheLookup 
    WebElement submiterr;
	
	@FindBy(name="email")
	@CacheLookup 
    WebElement emailerr;
	
	@FindBy(name="passwd")
	@CacheLookup 
    WebElement passworderr;
	
	@FindBy(id="SubmitLogin")
	@CacheLookup 
    WebElement submitagain;
	
	public WebElement LoginErr()
	{
		return loginerr;
	}
	public WebElement SubmitErr()
	{
		return submiterr;
	}
	public WebElement EmailErr()
	{
		return emailerr;
	}
	public WebElement PasswordErr()
	{
		return passworderr;
	}
	public WebElement SubmitAgain()
	{
		return submitagain;
	}
}
