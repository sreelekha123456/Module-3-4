package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignupPOF {
	WebDriver driver;
	public SignupPOF(WebDriver driver)
	{
		this.driver =driver;
	    PageFactory.initElements(driver,this);
	}
	@FindBy(className="login")
	@CacheLookup
	WebElement SignIn;
	@FindBy(id="email_create")
	@CacheLookup
	WebElement Email;
	@FindBy(id="SubmitCreate") 
	@CacheLookup
	WebElement CreateAccount;
	@FindBy(id="id_gender1")
	@CacheLookup
	WebElement Gender;
	@FindBy(id="customer_firstname")
	@CacheLookup
	WebElement FirstName;
	@FindBy(name="customer_lastname")
	@CacheLookup
	WebElement LastName;
	@FindBy(id="email")  
	@CacheLookup
	WebElement emailid;
	@FindBy(name="passwd")
	@CacheLookup
	WebElement Password;
	@FindBy(name="company")
	@CacheLookup
	WebElement Company;
	@FindBy(id="address1")
	@CacheLookup
	WebElement Address;
	@FindBy(id="city")
	@CacheLookup
	WebElement City;
	@FindBy(id="id_state")
	@CacheLookup
	WebElement State;
	@FindBy(name="postcode")
	@CacheLookup
	WebElement Postcode;
	@FindBy(id="id_country")
	@CacheLookup
	WebElement Country;
	@FindBy(id="other")
	@CacheLookup
	WebElement AddInfo;
	
	@FindBy(id="phone_mobile")
	@CacheLookup
	WebElement Mobile;
	
	@FindBy(id="alias")
	@CacheLookup
	WebElement aliasAddress;
	@FindBy(id="submitAccount")
	@CacheLookup
	WebElement Register;
	@FindBy(xpath=".//*[@id='columns']/div[1]/a/i")
	@CacheLookup
	WebElement ClickonHome;
	@FindBy(xpath="//a[@title='View my shopping cart']")
	@CacheLookup
	WebElement Cart;
	@FindBy(xpath="//a[@title='Women']")
	@CacheLookup
	WebElement ClickWomen;
	@FindBy(xpath=".//*[@id='block_top_menu']/ul/li[3]/a")
	@CacheLookup
	WebElement ClickTshirts;
   @FindBy(xpath="//*[@id=\"center_column\"]/ul/li[3]/div/div[1]/div/a[1]/img")
	@CacheLookup
	WebElement SelectProduct;
	
	
	@FindBy(className="exclusive") 
	@CacheLookup
	WebElement AddtoCart;
	@FindBy(xpath="//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span")
	@CacheLookup
	WebElement Proceedtocheckout;

	
	
	
	
	
	public WebElement ClickSignIn() {
		return SignIn;
	}public WebElement Email() {
		return Email;
	}public WebElement ClickCreateAccount() {
		return CreateAccount;
	}
	public WebElement Gender() {
		return Gender;
	}
	public WebElement FirstName() {
		return FirstName;
	}
	public WebElement LastName() {
		return LastName;
	}
	public WebElement Emailid() {
		return emailid;
	}
	public WebElement Password() {
		return Password;
	}
	public WebElement Company() {
		return Company;
	}
	public WebElement Address() {
		return Address;
	}
	public WebElement City() {
		return City;
	}
	public WebElement State() {
		return State;
	}
	public WebElement Postcode() {
		return Postcode;
	}
	public WebElement Country() {
		return Country;
	}
	public WebElement Mobile() {
		return Mobile;
	}
	public WebElement AliasAddress() {
		return aliasAddress;
	}
	public WebElement ClickRegister() {
		return Register;
	}
	public WebElement AddInfo() {
		return AddInfo;
	}
	public WebElement ClickonHome() {
		return ClickonHome;
	}
	public WebElement ClickonCart() {
		return AddtoCart;
	}
	public WebElement ClickonWomen() {
		return ClickWomen;
	}
	
	public WebElement selectProduct() {
		return SelectProduct;
	}}
	
	
	

