package stepDefinitions;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import objectRepository.SignupPOF;

public class StepDefinition{

	WebDriver driver;
     SignupPOF sg;
	@Before
	public void before()
	{
		

		System.setProperty("webdriver.chrome.driver","C:\\Bantu Sahithi Modules\\chromedriver.exe");  
	        driver = new ChromeDriver();
	        sg = new SignupPOF(driver);
	        driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
	}

	   @Given("^the user on home page$")
	    public void the_user_on_home_page() throws Throwable {
	      driver.get("http://automationpractice.com/index.php");  
	    }

	    @When("^the user clicks on sign in link$")
	    public void the_user_clicks_on_sign_in_link() throws Throwable {
	     sg.ClickSignIn().click();
	     Thread.sleep(1000);
	    }

	    @Then("^the user navigates to sign up page$")
	    public void the_user_navigates_to_sign_up_page() throws Throwable {
	       
	    }

	    @Then("^the user navigates to registration page$")
	    public void the_user_navigates_to_registration_page() throws Throwable {
	       
	    }

	    @Then("^the user is navigated to My Account page$")
	    public void the_user_is_navigated_to_my_account_page() throws Throwable {
	       
	    }

	    @And("^the enters valid email address$")
	    public void the_enters_valid_email_address() throws Throwable {
	       sg.Email().sendKeys("pralsaighrrarrhuju@gmail.com");
	       Thread.sleep(1000);
	    }

	    @And("^the user clicks on create an account$")
	    public void the_user_clicks_on_create_an_account() throws Throwable {
	       sg.ClickCreateAccount().click();
	    }

	    @And("^the user selects gender$")
	    public void the_user_selects_gender() throws Throwable {
	       sg.Gender().click();
	       Thread.sleep(1000);
	    }

	    @And("^the user enters first name$")
	    public void the_user_enters_first_name() throws Throwable {
	       sg.FirstName().sendKeys("Bantu");
	       Thread.sleep(1000);
	    }

	  @And("^the user enters last name$")
	    public void the_user_enters_last_name() throws Throwable {
	       sg.LastName().sendKeys("sahi");
	       Thread.sleep(1000);
	    }

	    @And("^the user enters Additional Information$")
	    public void the_user_enters_additional_information() throws Throwable {
	        sg.AddInfo().sendKeys("hello");
	    }

	    @And("^the user enters email$")
	    public void the_user_enters_email() throws Throwable {
	       sg.Email().sendKeys("Bantusahithhh@gmail.com");
	       Thread.sleep(1000);
	    }

	    @And("^the user enters password$")
	    public void the_user_enters_password() throws Throwable {
	       sg.Password().sendKeys("12345@");
	       Thread.sleep(1000);
	    }

	    
	    @And("^the user enters company$")
	    public void the_user_enters_company() throws Throwable {
	       sg.Company().sendKeys("Capgemini");
	       Thread.sleep(1000);
	    }

	    @And("^the user enters address$")
	    public void the_user_enters_address() throws Throwable {
	       sg.Address().sendKeys("knr");
	       
	       Thread.sleep(1000);
	    }

	    @And("^the user enters city$")
	    public void the_user_enters_city() throws Throwable {
	       sg.City().sendKeys("hydd");
	       Thread.sleep(1000);
	    }

	    @And("^the user enters state$")
	    public void the_user_enters_state() throws Throwable {
	       sg.State().sendKeys("tg");
	       
	       Thread.sleep(1000);
	    }

	    @And("^the user enters postal code$")
	    public void the_user_enters_postal_code() throws Throwable {
	       sg.Postcode().sendKeys("12345");
	       Thread.sleep(1000);
	    }

	    @And("^the user enters country$")
	    public void the_user_enters_country() throws Throwable {
	       sg.Country().sendKeys("India");
	       Thread.sleep(1000);
	    }

	    @And("^the user enters mobile phone$")
	    public void the_user_enters_mobile_phone() throws Throwable {
	       sg.Mobile().sendKeys("9874563210");
	       Thread.sleep(1000);
	    }

	    @And("^the user clicks on Register$")
	    public void the_user_clicks_on_register() throws Throwable {
	       sg.ClickRegister().click();
	       }
	    
	       @And("^the user clicks on home button$")
	       public void the_user_clicks_on_home_button() throws Throwable {
	           sg.ClickonHome().click();
	       }

	       @And("^the user clicks on cart$")
	       public void the_user_clicks_on_cart() throws Throwable {
	           sg.ClickonCart().click();
	       }

	       @And("^the user clicks on Women$")
	       public void the_user_clicks_on_women() throws Throwable {
	           sg.ClickonWomen().click();
	           
	       } 
	       @And("^user selects a product$")
	       public void user_selects_a_product() throws Throwable {
	           sg.selectProduct().click();
	           
	       }

	       @And("^user Adds to cart$")
	       public void user_adds_to_cart() throws Throwable {
	           sg.AddtoCart().click();
	           Thread.sleep(3000);
	       }
	       @And("^user clicks on proceed to checkout$")
	       public void user_clicks_on_proceed_to_checkout() throws Throwable {
	           sg.Clickonproceed().click();
	       }
	       @And("^the user clicks on TShirts$")
	       public void the_user_clicks_on_tshirts() throws Throwable {
	           sg.ClickonTShirts().click();
	       }

}

	       @And("^the user clicks on Dresses$")
	       public void the_user_clicks_on_dresses() throws Throwable {
	           sg.ClickonDresses().click();
	       }

	     	      
	       }
	       
	    

