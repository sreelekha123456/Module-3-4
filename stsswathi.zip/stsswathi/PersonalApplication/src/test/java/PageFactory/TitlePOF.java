package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TitlePOF {
	WebDriver driver;
	public TitlePOF(WebDriver driver)
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="html/body/form/table/tbody/tr[1]/td")
	@CacheLookup // to store the element in cache memory
    WebElement title;
	
	@FindBy(id="rdbCategory")
	@CacheLookup // to store the element in cache memory
    WebElement ApplicantCat;
	@FindBy(id="txtName")
	@CacheLookup // to store the element in cache memory
    WebElement Name;
	@FindBy(id="txtFirstName")
	@CacheLookup // to store the element in cache memory
    WebElement firstname;
	
	@FindBy(id="txtLastName")
	@CacheLookup // to store the element in cache memory
    WebElement lastname;
	@FindBy(id="txtFatherName")
	@CacheLookup // to store the element in cache memory
    WebElement fathername;
	
	@FindBy(id="txtDOB")
	@CacheLookup // to store the element in cache memory
    WebElement DOB;
	@FindBy(id="txtMobileNo")
	@CacheLookup // to store the element in cache memory
    WebElement MobileNo;
	@FindBy(id="txtEmail")
	@CacheLookup // to store the element in cache memory
    WebElement Email;
	@FindBy(id="txtLndLine")
	@CacheLookup // to store the element in cache memory
    WebElement Landline;
	
	@FindBy(id="rdbFemale")
	@CacheLookup // to store the element in cache memory
    WebElement gender;
	
	@FindBy(id="rdbOfficeAdd")
	@CacheLookup // to store the element in cache memory
    WebElement Address;
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup // to store the element in cache memory
    WebElement address;
	
	@FindBy(id="btnSubmit")
	@CacheLookup // to store the element in cache memory
    WebElement submitbutton;
	@FindBy(xpath="html/body/h1")
	@CacheLookup // to store the element in cache memory
    WebElement result;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[1]/td")
	@CacheLookup // to store the element in cache memory
    WebElement resultofresetbtn;
	
	
	public WebElement title()
	{
		return title;
	}

	public WebElement ApplicantCat()
	{
		return ApplicantCat;
	}

	
	public WebElement Name()
	{
		return Name;
	}
	
	public WebElement firstname()
	{
		return firstname;
	}
	
	public WebElement lastname()
	{
		return lastname;
	}
	
	public WebElement fathername()
	{
		return fathername;
	}
	
	public WebElement DOB()
	{
		return DOB;
	}
	public WebElement MobileNo()
	{
		return MobileNo;
	}
	public WebElement Email()
	{
		return Email;
	}
	public WebElement Landline()
	{
		return Landline;
	}
	public WebElement Address()
	{
		return Address;
	}
	public WebElement gender()
	{
		return gender;
	}
	public WebElement address()
	{
		return address;
	}
	public WebElement submitbutton()
	{
		return submitbutton;
	}
	public WebElement result()
	{
		return result;
	}
	
	public WebElement resultofresetbtn()
	{
		return resultofresetbtn;
	}
}
