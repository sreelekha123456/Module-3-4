package StepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageFactory.TitlePOF;
import PageFactory.WebElementsPOF;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitions {
	WebDriver driver=new FirefoxDriver();
	TitlePOF pof;
	WebElementsPOF wpof;
	
	@Given("^Launch the application browser$")
    public void launch_the_application_browser_firefox_google_chrome_ie() throws Throwable {
		pof= new TitlePOF(driver);
		driver.get("file:///C:/Users/learning/Desktop/html/UserInformation.html");
		System.out.println("Opened the file in the browser");
    }

    @When("^User opens the personal information website$")
    public void user_opens_the_personal_information_website() throws Throwable {
    	
    }

    @Then("^verify the title of the page opened$")
    public void verify_the_title_of_the_page_opened() throws Throwable {
    
    String actual = pof.title().getText();
    String expected = "PERSONAL INFORMATION";
    Assert.assertEquals(expected, actual);
    System.out.println("Title is verified");
    Thread.sleep(1500);
    }

    @And("^check whether the title is matching the expected title$")
    public void check_whether_the_title_is_matching_the_expected_title() throws Throwable {
        
    }
    @And("^close the Browser$")
    public void close_the_browser() throws Throwable {
        driver.close();
        System.out.println("Closed the browser");
    }

    
    @Given("^User is on the valid webpage$")
    public void user_is_on_the_valid_webpage() throws Throwable {
    	wpof= new WebElementsPOF(driver);
    	driver.get("file:///C:/Users/learning/Desktop/html/UserInformation.html");
    	 String actual = wpof.title().getText();
    	    String expected = "PERSONAL INFORMATION";
    	    Assert.assertEquals(expected, actual);
    	    System.out.println("User is on the valid page");
    	    Thread.sleep(1500);
    }

    @When("^selects the Category$")
    public void selects_the_category() throws Throwable {
        
    }

    @Then("^Click on Submit$")
    public void click_on_submit() throws Throwable {
    	 wpof.submitbutton().click();
    }

    @And("^Name of the applicant$")
    public void name_of_the_applicant() throws Throwable {
        wpof.Name().sendKeys("swathi");
    }

    @And("^Firstname as on  PANCard$")
    public void firstname_as_on_pancard() throws Throwable {
        wpof.firstname().sendKeys("swa");
    }

    @And("^Lastname  as on PANCard$")
    public void lastname_as_on_pancard() throws Throwable {
        wpof.lastname().sendKeys("pannem");
    }

    @And("^fathersname$")
    public void fathersname() throws Throwable {
        wpof.fathername().sendKeys("venu");
    }

    @And("^date of Birth$")
    public void date_of_birth() throws Throwable {
        wpof.DOB().sendKeys("19-06-1996");
    }

    @And("^gender is selected$")
    public void gender_is_selected() throws Throwable {
      wpof.gender().click();
    }

    @And("^mobileNumber is given$")
    public void mobilenumber_is_given() throws Throwable {
        wpof.MobileNo().sendKeys("9687654321");
    }

    @And("^emailID$")
    public void emailid() throws Throwable {
        wpof.Email().sendKeys("swa@gmail.com");
    }

    @And("^landLine$")
    public void landline() throws Throwable {
        wpof.Landline().sendKeys("08812256079");
    }

    @And("^selects Communication$")
    public void selects_communication() throws Throwable {
        wpof.Address().click();
    }

    @And("^gives Residence Address$")
    public void gives_residence_address() throws Throwable {
        wpof.address().sendKeys("Capgemini,Hyderabad");
    }


    @And("^verify the result page$")
    public void verify_the_result_page() throws Throwable {
    	String actual = pof.result().getText();
	    String expected = "PAN Card: User information saved successfully, Now next step is to make payment";
	    Assert.assertEquals(expected, actual);
    }

   
    @And("^closed the Browser$")
    public void closed_the_browser() throws Throwable {
        driver.close();
    }
    
    
    @Given("^I want to write the name of the applicant as (.+)$")
    public void i_want_to_write_the_name_of_the_applicant_as(String name) throws Throwable {
    	pof= new TitlePOF(driver);
    	driver.get("file:///C:/Users/learning/Desktop/html/UserInformation.html");
    	 String actual = pof.title().getText();
    	    String expected = "PERSONAL INFORMATION";
    	    Assert.assertEquals(expected, actual);
        pof.Name().sendKeys(name);
    }
    
    @Then("^Clicks on reset$")
    public void clicks_on_reset() throws Throwable {
        pof.resultofresetbtn().click();
        System.out.println("Reset is selected");
    }


    

    @And("^firstname as (.+)$")
    public void firstname_as(String fname) throws Throwable {
    	pof.firstname().sendKeys(fname);
    }

    @And("^lastname as (.+)$")
    public void lastname_as(String lname) throws Throwable {
    	 pof.lastname().sendKeys(lname);
    }

    @And("^Fathersname as (.+)$")
    public void fathersname_as(String fathername) throws Throwable {
        pof.fathername().sendKeys(fathername);
    }

    @And("^Date of Birth as (.+)$")
    public void date_of_birth_as(String dob) throws Throwable {
        pof.DOB().sendKeys(dob);
    }

    @And("^Gender as (.+)$")
    public void gender_as(String gender) throws Throwable {
        
    }

    @And("^phonenumber as (.+)$")
    public void phonenumber_as(String phno) throws Throwable {
        pof.MobileNo().sendKeys(phno);
    }

    @And("^verifies the result page$")
    public void verifies_the_result_page() throws Throwable {
    	String actual = pof.resultofresetbtn().getText();
    	String expected = "PERSONAL INFORMATION";
	    Assert.assertEquals(expected, actual);
	    System.out.println("User information is reset");
	    Thread.sleep(1500);
    }
	
    @And("^closes the Browser$")
    public void closes_the_browser() throws Throwable {
        driver.close();
    }
    
    
    /**********For error capturing************/
    

    @Given("^User doesnt give his name and submit display error mesage$")
    public void user_doesnt_give_his_name_and_submit_display_error_mesage() throws Throwable {
    	pof= new TitlePOF(driver);
    	driver.get("file:///C:/Users/learning/Desktop/html/UserInformation.html");
    	 String actual = pof.title().getText();
    	    String expected = "PERSONAL INFORMATION";
    	    Assert.assertEquals(expected, actual);
        
    }

    @When("^doesnot selects the Category display error msg$")
    public void doesnot_selects_the_category_display_error_msg() throws Throwable {
        
    }

    @Then("^Display the error messages correspondingly$")
    public void display_the_error_messages_correspondingly() throws Throwable {
        
    }

    @And("^not giving his Name$")
    public void not_giving_his_name() throws Throwable {
    	pof.Name().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Applicant Name ";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    	
    }

    @And("^No Firstname diplay error$")
    public void no_firstname_diplay_error() throws Throwable {
    	pof.Name().sendKeys("Bhavya");
    	pof.firstname().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the First Name ";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^lastname is not given diplay error$")
    public void lastname_is_not_given_diplay_error() throws Throwable {
    	
    	pof.firstname().sendKeys("Pudi");
    	pof.lastname().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Last Name ";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^display error without fathersname$")
    public void display_error_without_fathersname() throws Throwable {
    	
    	pof.lastname().sendKeys("swathi");
    	pof.fathername().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Father Name ";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^without date of Birth$")
    public void without_date_of_birth() throws Throwable {
    	
    	pof.fathername().sendKeys("venu");
    	pof.DOB().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the DOB";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^Their gender is not selected$")
    public void their_gender_is_not_selected() throws Throwable {
    	
    	pof.DOB().sendKeys("16-16-1996");
    	pof.gender().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please select the Gender";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^user mobileNumber is given$")
    public void user_mobilenumber_is_given() throws Throwable {
    	
    	pof.gender().click();
    	pof.MobileNo().sendKeys("9087654321");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please enter valid mobile no";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^valid emailID is not given$")
    public void valid_emailid_is_not_given() throws Throwable {
    	pof.MobileNo().clear();
    	pof.MobileNo().sendKeys("9652713406");
        pof.Email().sendKeys("swathi@gmail");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please enter valid Email id ";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^verified landLine is not given$")
    public void verified_landline_is_not_given() throws Throwable {
    	
    }

    @And("^selection of Communication is not done$")
    public void selection_of_communication_is_not_done() throws Throwable {
    	pof.Email().clear();
        pof.Email().sendKeys("swa@gmail.com");
        pof.Landline().sendKeys("08812236091");
        pof.Address().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please select the Type of Communication ";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @And("^Residence Address is not selected$")
    public void residence_address_is_not_selected() throws Throwable {
    	
        pof.Address().click();
        pof.address().sendKeys("");
    	pof.submitbutton().click();
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "please enter the Addresss ";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

}
