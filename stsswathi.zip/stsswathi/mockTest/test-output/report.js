$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("journel.feature");
formatter.feature({
  "line": 3,
  "name": "Capgemini International Research Journal",
  "description": "",
  "id": "capgemini-international-research-journal",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@CapgeminiInternationalResearchJournalFeatures"
    }
  ]
});
formatter.background({
  "line": 5,
  "name": "Login page for Paper Submission for International Journal",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "User is on valid Login page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 8,
  "name": "Verification of Subject Category link",
  "description": "",
  "id": "capgemini-international-research-journal;verification-of-subject-category-link",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "User is on valid Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "User clicks on click here to know subject categories",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "Subject Category page should be displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "Clicks Back Link",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "Login page is displayed",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "Login page for Paper Submission for International Journal",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "User is on valid Login page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 15,
  "name": "Verification of error message of Username abd Password",
  "description": "",
  "id": "capgemini-international-research-journal;verification-of-error-message-of-username-abd-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "User is on valid Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "User leaves UserName Empty",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "Clicks on Login button",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "Error message Please enter UserName displays",
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "User enters valid UserName",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "User leaves Password Empty",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "Clicks on Login button",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "Error message Please enter Password displays",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "User enters valid Password",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "Clicks on Login button",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "User is navigated to Registration  page",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 5,
  "name": "Login page for Paper Submission for International Journal",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "User is on valid Login page",
  "keyword": "Given "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 28,
  "name": "Registration to Capgemini International Research Journal",
  "description": "",
  "id": "capgemini-international-research-journal;registration-to-capgemini-international-research-journal",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "User has Logged in with valid credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "User leaves Full Name empty",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Please fill the Full Name Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "User enters valid Full Name",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "User leaves Email empty",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "Please fill the Email Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 37,
  "name": "User enters vaild Email",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "User leaves Mobile No empty",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "Please fill the Mobile No Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 41,
  "name": "User enters invalid Mobile No",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 43,
  "name": "Please enter valid Contact no Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 44,
  "name": "User enters vaild Mobile No",
  "keyword": "And "
});
formatter.step({
  "line": 45,
  "name": "User selects Gender",
  "keyword": "And "
});
formatter.step({
  "line": 46,
  "name": "User unselects City",
  "keyword": "And "
});
formatter.step({
  "line": 47,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 48,
  "name": "Please select city Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 49,
  "name": "User selects City",
  "keyword": "And "
});
formatter.step({
  "line": 50,
  "name": "User unselects State",
  "keyword": "And "
});
formatter.step({
  "line": 51,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 52,
  "name": "Please select state Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 53,
  "name": "User selects State",
  "keyword": "And "
});
formatter.step({
  "line": 54,
  "name": "User leaves Subject Category empty",
  "keyword": "And "
});
formatter.step({
  "line": 55,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 56,
  "name": "Please fill the Subject Category Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 57,
  "name": "User enters vaild Subject Category",
  "keyword": "And "
});
formatter.step({
  "line": 58,
  "name": "User leaves Paper Name empty",
  "keyword": "And "
});
formatter.step({
  "line": 59,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 60,
  "name": "Please fill the Paper Name Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 61,
  "name": "User enters vaild Paper Name",
  "keyword": "And "
});
formatter.step({
  "line": 62,
  "name": "User leaves No of Author empty",
  "keyword": "And "
});
formatter.step({
  "line": 63,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 64,
  "name": "Please fill the authors Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 65,
  "name": "User enters vaild No of Author",
  "keyword": "And "
});
formatter.step({
  "line": 66,
  "name": "User leaves Company Name empty",
  "keyword": "And "
});
formatter.step({
  "line": 67,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 68,
  "name": "Please fill Company Name Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 69,
  "name": "User enters vaild Company Name",
  "keyword": "And "
});
formatter.step({
  "line": 70,
  "name": "User leaves Designation empty",
  "keyword": "And "
});
formatter.step({
  "line": 71,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 72,
  "name": "Please fill Designation Alert box is popped",
  "keyword": "Then "
});
formatter.step({
  "line": 73,
  "name": "User enters vaild Designation",
  "keyword": "And "
});
formatter.step({
  "line": 74,
  "name": "Clicks on Confirm Registration button",
  "keyword": "And "
});
formatter.step({
  "line": 75,
  "name": "Registation completed message should be displayed",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});