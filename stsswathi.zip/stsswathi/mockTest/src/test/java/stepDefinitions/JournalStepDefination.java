package stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import objectRepository.LoginPOF;
import objectRepository.RegistrationPOF;
import objectRepository.SuccessPOF;
import objectRepository.TopicsPOF;

public class JournalStepDefination
    {
	WebDriver driver;
	LoginPOF log;
	TopicsPOF top;
	RegistrationPOF reg;
	SuccessPOF sp;
	
	@Before
    public void before()
    {
		System.setProperty("webdriver.chrome.driver","C:\\chromedriver_win32");  
        driver = new ChromeDriver();
        driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		log = new LoginPOF(driver);
		top = new TopicsPOF(driver);
		reg = new RegistrationPOF(driver);
		sp = new SuccessPOF(driver);
    }
	
	@Given("^User is on valid Login page$")
    public void user_is_on_valid_login_page() throws Throwable {
		driver.get("C:\\\\Ajournelwebpages\\\\login.html");
        String actual = log.Heading().getText();
        String expected = "Paper Submission for International Journal";
        Assert.assertEquals(expected, actual);
    }

    @Given("^User has Logged in with valid credentials$")
    public void user_has_logged_in_with_valid_credentials() throws Throwable {
        log.UserName().sendKeys("vrl");
        log.Password().sendKeys("vrl1234");
        log.LoginButton().click();
        Thread.sleep(1000);
    }

    @When("^User clicks on click here to know subject categories$")
    public void user_clicks_on_click_here_to_know_subject_categories() throws Throwable {
    	log.CategoryLink().click();
    }

    @When("^User leaves UserName Empty$")
    public void user_leaves_username_empty() throws Throwable {
    	log.UserName().sendKeys("");
    }

    @When("^User leaves Full Name empty$")
    public void user_leaves_full_name_empty() throws Throwable {
    	reg.FullName().sendKeys("");
    }

    @Then("^Subject Category page should be displayed$")
    public void subject_category_page_should_be_displayed() throws Throwable {
    	String expected = "Subject Categories :";
    	String actual = top.TitleName().getText();
        Assert.assertEquals(expected, actual);
        Thread.sleep(1000);
    }

    @Then("^Login page is displayed$")
    public void login_page_is_displayed() throws Throwable {
    	String actual = log.Heading().getText();
        String expected = "Paper Submission for International Journal";
        Assert.assertEquals(expected, actual);
        Thread.sleep(1000);
    }

    @Then("^Error message Please enter UserName displays$")
    public void error_message_please_enter_username_displays() throws Throwable {
    	String actual = log.UserError().getText();
        String expected = "* Please enter userName.";
        Assert.assertEquals(expected, actual);
        Thread.sleep(1000);
    }

    @Then("^Error message Please enter Password displays$")
    public void error_message_please_enter_password_displays() throws Throwable {
    	String actual = log.PassError().getText();
        String expected = "* Please enter password.";
        Assert.assertEquals(expected, actual);
        Thread.sleep(1000);
    }

    @Then("^User is navigated to Registration  page$")
    public void user_is_navigated_to_registration_page() throws Throwable {
    	String expected = "Capgemini International Research Journal";
    	String actual  = driver.getTitle();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    }

    @Then("^Please fill the Full Name Alert box is popped$")
    public void please_fill_the_full_name_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Full Name";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please fill the Email Alert box is popped$")
    public void please_fill_the_email_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Email";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please fill the Mobile No Alert box is popped$")
    public void please_fill_the_mobile_no_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Mobile No.";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please enter valid Contact no Alert box is popped$")
    public void please_enter_valid_contact_no_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please enter valid Contact no.";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please select city Alert box is popped$")
    public void please_select_city_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please select city";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please select state Alert box is popped$")
    public void please_select_state_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please select state";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please fill the Subject Category Alert box is popped$")
    public void please_fill_the_subject_category_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Subject Category";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please fill the Paper Name Alert box is popped$")
    public void please_fill_the_paper_name_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill the Paper Name";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please fill the authors Alert box is popped$")
    public void please_fill_the_authors_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Pls. fill the authors";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please fill Company Name Alert box is popped$")
    public void please_fill_company_name_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill Company Name";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Please fill Designation Alert box is popped$")
    public void please_fill_designation_alert_box_is_popped() throws Throwable {
    	Alert promptAlert = driver.switchTo().alert();
    	String expected = "Please fill Designation";
    	String actual = promptAlert.getText();
    	Assert.assertEquals(expected, actual);
    	Thread.sleep(1000);
    	promptAlert.accept();
    }

    @Then("^Registation completed message should be displayed$")
    public void registation_completed_message_should_be_displayed() throws Throwable {
    	String actual = sp.PageContent().getText();
        String expected = "Registration Completed!";
        Assert.assertEquals(expected, actual);
        Thread.sleep(1000);
    }

    @And("^Clicks Back Link$")
    public void clicks_back_link() throws Throwable {
    	top.BackLink().click();
    	Thread.sleep(1000);
    }

    @And("^Clicks on Login button$")
    public void clicks_on_login_button() throws Throwable {
    	log.LoginButton().click();
    	Thread.sleep(1000);
    }

    @And("^User enters valid UserName$")
    public void user_enters_valid_username() throws Throwable {
    	log.UserName().sendKeys("vrl");
    	Thread.sleep(1000);
    }

    @And("^User leaves Password Empty$")
    public void user_leaves_password_empty() throws Throwable {
    	log.Password().sendKeys("");
    }

    @And("^User enters valid Password$")
    public void user_enters_valid_password() throws Throwable {
    	log.Password().sendKeys("vrl1234");
    	Thread.sleep(1000);
    }

    @And("^Clicks on Confirm Registration button$")
    public void clicks_on_confirm_registration_button() throws Throwable {
    	Thread.sleep(1000);
    	reg.ConfirmButton().click();
    	Thread.sleep(1000);
    }

    @And("^User enters valid Full Name$")
    public void user_enters_valid_full_name() throws Throwable {
    	reg.FullName().sendKeys("Suman");
    }

    @And("^User leaves Email empty$")
    public void user_leaves_email_empty() throws Throwable {
    	reg.EmailId().sendKeys("");
    }

    @And("^User enters vaild Email$")
    public void user_enters_vaild_email() throws Throwable {
    	reg.EmailId().sendKeys("suman@gmail.com");
    }

    @And("^User leaves Mobile No empty$")
    public void user_leaves_mobile_no_empty() throws Throwable {
    	reg.MobileNo().sendKeys("");
    }

    @And("^User enters invalid Mobile No$")
    public void user_enters_invalid_mobile_no() throws Throwable {
    	reg.MobileNo().sendKeys("988888888888");
    }

    @And("^User enters vaild Mobile No$")
    public void user_enters_vaild_mobile_no() throws Throwable {
    	reg.MobileNo().clear();
    	reg.MobileNo().sendKeys("9444280084");
    }

    @And("^User selects Gender$")
    public void user_selects_gender() throws Throwable {
    	reg.Gender().click();
    }

    @And("^User unselects City$")
    public void user_unselects_city() throws Throwable {
    	reg.City().click();
    }

    @And("^User selects City$")
    public void user_selects_city() throws Throwable {
    	reg.City().click();
    	Select val = new Select(reg.City());
    	val.selectByValue("Bangalore");
    }

    @And("^User unselects State$")
    public void user_unselects_state() throws Throwable {
    	reg.State().click();
    }

    @And("^User selects State$")
    public void user_selects_state() throws Throwable {
    	reg.State().click();
    	Select val = new Select(reg.State());
    	val.selectByValue("Karnataka");
    }

    @And("^User leaves Subject Category empty$")
    public void user_leaves_subject_category_empty() throws Throwable {
    	reg.SubjectCat().sendKeys("");
    }

    @And("^User enters vaild Subject Category$")
    public void user_enters_vaild_subject_category() throws Throwable {
    	reg.SubjectCat().sendKeys("Artificial Inteligence");
    }

    @And("^User leaves Paper Name empty$")
    public void user_leaves_paper_name_empty() throws Throwable {
    	reg.PaperName().sendKeys("");
    }

    @And("^User enters vaild Paper Name$")
    public void user_enters_vaild_paper_name() throws Throwable {
    	reg.PaperName().sendKeys("sasasa");
    }

    @And("^User leaves No of Author empty$")
    public void user_leaves_no_of_author_empty() throws Throwable {
    	reg.AuthorNo().sendKeys("");
    }

    @And("^User enters vaild No of Author$")
    public void user_enters_vaild_no_of_author() throws Throwable {
    	reg.AuthorNo().sendKeys("1");
    }

    @And("^User leaves Company Name empty$")
    public void user_leaves_company_name_empty() throws Throwable {
    	reg.Company().sendKeys("");
    }

    @And("^User enters vaild Company Name$")
    public void user_enters_vaild_company_name() throws Throwable {
    	reg.Company().sendKeys("Capgemini");
    }

    @And("^User leaves Designation empty$")
    public void user_leaves_designation_empty() throws Throwable {
    	reg.Desig().sendKeys("");
    }

    @And("^User enters vaild Designation$")
    public void user_enters_vaild_designation() throws Throwable {
        reg.Desig().sendKeys("Analyst");
    }
    
    @After
    public void after()
    {
    	driver.close();
    }
	/*
	WebDriver driver = new FirefoxDriver();
	@Given("^user navigate to valid url (.+)$")
    public void user_navigate_to_valid_url(String cuserslearningdesktopmodule4vvatm4mptsamplequeloginhtml) throws Throwable {
		driver.get("C:\\Ajournelwebpages\\login.html");
    }

    @When("^user enter (.+)$")
    public void user_enter(String username) throws Throwable {
    	driver.findElement(By.name("userName")).sendKeys(username);
    }

    @Then("^cick on login$")
    public void cick_on_login() throws Throwable {
    	driver.findElement(By.cssSelector("input.btn")).click();
    	String url=driver.getCurrentUrl();
    	Assert.assertEquals("C:\\Ajournelwebpages\\registration.html", url);
    }

    @And("^enter (.+)$")
    public void enter(String password) throws Throwable {
    	driver.findElement(By.name("userPwd")).sendKeys(password);
    }
    //**************registration process************************************//*/
   /* @Given("^enter url in browser$")
    public void enter_url_in_browser() throws Throwable {
       
    }

    @When("^user enter first name$")
    public void user_enter_first_name() throws Throwable {
       
    }

    @Then("^user Registration has to complete$")
    public void user_registration_has_to_complete() throws Throwable {
       
    }

    @And("^user enter email$")
    public void user_enter_email() throws Throwable {
       
    }

    @And("^user enter mobile number$")
    public void user_enter_mobile_number() throws Throwable {
       
    }

    @And("^user select gender$")
    public void user_select_gender() throws Throwable {
       
    }

    @And("^user select city$")
    public void user_select_city() throws Throwable {
       
    }

    @And("^user select state$")
    public void user_select_state() throws Throwable {
       
    }

    @And("^user enter subject categories$")
    public void user_enter_subject_categories() throws Throwable {
       
    }

    @And("^user enter paper name$")
    public void user_enter_paper_name() throws Throwable {
       
    }

    @And("^user enter company name and designation$")
    public void user_enter_company_name_and_designation() throws Throwable {
       
    }

    @And("^click on confirm registration$")
    public void click_on_confirm_registration() throws Throwable {
       
    }

    @And("^check more outcomes$")
    public void check_more_outcomes() throws Throwable {
       
    }
    */

}
