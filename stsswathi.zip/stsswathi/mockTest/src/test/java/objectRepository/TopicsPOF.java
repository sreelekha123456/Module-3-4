package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TopicsPOF {
	WebDriver driver;
	public TopicsPOF(WebDriver driver)
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="/html/body/p/a")
	@CacheLookup // to store the element in cache memory
    WebElement back;
	
	@FindBy(xpath="/html/body/h3")
	@CacheLookup // to store the element in cache memory
    WebElement title;
	
	
	public WebElement BackLink()
	{
		return back;
	}
	
	public WebElement TitleName()
	{
		return title;
	}
}
