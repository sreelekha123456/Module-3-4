package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPOF {
	WebDriver driver;
	public RegistrationPOF(WebDriver driver)
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	@FindBy(id="txtFullName")
	@CacheLookup // to store the element in cache memory
    WebElement fullName;
	
	@FindBy(id="txtEmail")
	@CacheLookup // to store the element in cache memory
    WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup // to store the element in cache memory
    WebElement mobile;
	
	@FindBy(id="gender")
	@CacheLookup // to store the element in cache memory
    WebElement gender;
	
	@FindBy(name="city")
	@CacheLookup // to store the element in cache memory
    WebElement city;
	
	@FindBy(name="state")
	@CacheLookup // to store the element in cache memory
    WebElement state;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup // to store the element in cache memory
    WebElement subCat;
	
	@FindBy(id="txtDebit")
	@CacheLookup // to store the element in cache memory
    WebElement paperName;
	
	@FindBy(id="txtCvv")
	@CacheLookup // to store the element in cache memory
    WebElement author;
	
	@FindBy(id="txtMonth")
	@CacheLookup // to store the element in cache memory
    WebElement company;
	
	@FindBy(id="txtYear")
	@CacheLookup // to store the element in cache memory
    WebElement desig;
	
	@FindBy(xpath="//input[@id='btnPayment']")
	//@CacheLookup // to store the element in cache memory
    WebElement confirmBtn;
	
	public WebElement FullName()
	{
		return fullName;
	}
	
	public WebElement EmailId()
	{
		return email;
	}
	
	public WebElement MobileNo()
	{
		return mobile;
	}
	
	public WebElement Gender()
	{
		return gender;
	}
	
	public WebElement City()
	{
		return city;
	}
	
	public WebElement State()
	{
		return state;
	}
	
	public WebElement SubjectCat() {
		return subCat;
	}

	public WebElement PaperName() {
		return paperName;
	}

	public WebElement AuthorNo() {
		return author;
	}

	public WebElement Company() {
		return company;
	}

	public WebElement Desig() {
		return desig;
	}
	
	public WebElement ConfirmButton()
	{
		return confirmBtn;
	}
}
