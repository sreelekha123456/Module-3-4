package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPOF {

	WebDriver driver;
	public LoginPOF(WebDriver driver)
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	@FindBy(name="userName")
	@CacheLookup // to store the element in cache memory
    WebElement userName;
	
	@FindBy(name="userPwd")
	@CacheLookup // to store the element in cache memory
    WebElement password;
	
	@FindBy(xpath="//*[@id=\'mainCnt\']/div/div/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup // to store the element in cache memory
    WebElement loginBtn;
	
	@FindBy(xpath="//*[@id=\'mainCnt\']/div/div/form/h3/a")
	@CacheLookup // to store the element in cache memory
    WebElement link;
	
	@FindBy(xpath="//*[@id='mainCnt']/div/div/h3")
	//@CacheLookup // to store the element in cache memory
    WebElement heading;
	
	@FindBy(id="userErrMsg")
	//@CacheLookup // to store the element in cache memory
    WebElement userErr;
	
	@FindBy(id="pwdErrMsg")
	//@CacheLookup // to store the element in cache memory
    WebElement passErr;
	
	public WebElement UserName()
	{
		return userName;
	}
	
	public WebElement Password()
	{
		return password;
	}
	
	public WebElement LoginButton()
	{
		return loginBtn;
	}
	
	public WebElement CategoryLink()
	{
		return link;
	}
	
	public WebElement Heading()
	{
		return heading;
	}
	
	public WebElement UserError()
	{
		return userErr;
	}
	
	public WebElement PassError()
	{
		return passErr;
	}
	

}
