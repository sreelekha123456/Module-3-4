package StepsForMystore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration {
	WebDriver driver = new FirefoxDriver();
	
	 @Given("^user navigate url$")
	    public void user_navigate_url() throws Throwable {
		 driver.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");   
	    }
   

    @When("^user enter (.+)$")
    public void user_enter(String email) throws Throwable {
       driver.findElement(By.name("email")).sendKeys(email);
    }

    @Then("^cick on login$")
    public void cick_on_login() throws Throwable {
    	driver.findElement(By.id("SubmitLogin")).click();
    }

    @And("^enter (.+)$")
    public void enter(String password) throws Throwable {
    	driver.findElement(By.name("passwd")).sendKeys(password);
    }

}
