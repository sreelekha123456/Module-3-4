package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsM4 {
	WebDriver driver;
	public StepsM4(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	@FindBy(name="userName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath=".//*[@id='mainCnt']/div/div/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement logbtn;
	public WebElement EnterUserName()
	{
		
		return userName;
	}
	  @Given("^User is on valid Login page$")
	    public void user_is_on_valid_login_page() throws Throwable {
	       
	    }

	    @Given("^User has Logged in with valid credentials$")
	    public void user_has_logged_in_with_valid_credentials() throws Throwable {
	       
	    }

	    @When("^User clicks on click here to know subject categories$")
	    public void user_clicks_on_click_here_to_know_subject_categories() throws Throwable {
	       
	    }

	    @When("^User leaves UserName Empty$")
	    public void user_leaves_username_empty() throws Throwable {
	       
	    }

	    @When("^User leaves Full Name empty$")
	    public void user_leaves_full_name_empty() throws Throwable {
	       
	    }

	    @Then("^Subject Category page should be displayed$")
	    public void subject_category_page_should_be_displayed() throws Throwable {
	       
	    }

	    @Then("^Login page is displayed$")
	    public void login_page_is_displayed() throws Throwable {
	       
	    }

	    @Then("^Error message Please enter UserName displays$")
	    public void error_message_please_enter_username_displays() throws Throwable {
	       
	    }

	    @Then("^Error message Please enter Password displays$")
	    public void error_message_please_enter_password_displays() throws Throwable {
	       
	    }

	    @Then("^User is navigated to Registration  page$")
	    public void user_is_navigated_to_registration_page() throws Throwable {
	       
	    }

	    @Then("^Please fill the Full Name Alert box is popped$")
	    public void please_fill_the_full_name_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please fill the Email Alert box is popped$")
	    public void please_fill_the_email_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please fill the Mobile No Alert box is popped$")
	    public void please_fill_the_mobile_no_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please enter valid Contact no Alert box is popped$")
	    public void please_enter_valid_contact_no_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please select city Alert box is popped$")
	    public void please_select_city_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please select state Alert box is popped$")
	    public void please_select_state_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please fill the Subject Category Alert box is popped$")
	    public void please_fill_the_subject_category_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please fill the Paper Name Alert box is popped$")
	    public void please_fill_the_paper_name_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please fill the authors Alert box is popped$")
	    public void please_fill_the_authors_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please fill Company Name Alert box is popped$")
	    public void please_fill_company_name_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Please fill Designation Alert box is popped$")
	    public void please_fill_designation_alert_box_is_popped() throws Throwable {
	       
	    }

	    @Then("^Registation completed message should be displayed$")
	    public void registation_completed_message_should_be_displayed() throws Throwable {
	       
	    }

	    @And("^Clicks Back Link$")
	    public void clicks_back_link() throws Throwable {
	       
	    }

	    @And("^Clicks on Login button$")
	    public void clicks_on_login_button() throws Throwable {
	       
	    }

	    @And("^User enters valid UserName$")
	    public void user_enters_valid_username() throws Throwable {
	       
	    }

	    @And("^User leaves Password Empty$")
	    public void user_leaves_password_empty() throws Throwable {
	       
	    }

	    @And("^User enters valid Password$")
	    public void user_enters_valid_password() throws Throwable {
	       
	    }

	    @And("^Clicks on Confirm Registration button$")
	    public void clicks_on_confirm_registration_button() throws Throwable {
	       
	    }

	    @And("^User enters valid Full Name$")
	    public void user_enters_valid_full_name() throws Throwable {
	       
	    }

	    @And("^User leaves Email empty$")
	    public void user_leaves_email_empty() throws Throwable {
	       
	    }

	    @And("^User enters vaild Email$")
	    public void user_enters_vaild_email() throws Throwable {
	       
	    }

	    @And("^User leaves Mobile No empty$")
	    public void user_leaves_mobile_no_empty() throws Throwable {
	       
	    }

	    @And("^User enters invalid Mobile No $")
	    public void user_enters_invalid_mobile_no() throws Throwable {
	       
	    }

	    @And("^User enters vaild Mobile No$")
	    public void user_enters_vaild_mobile_no() throws Throwable {
	       
	    }

	    @And("^User selects Gender$")
	    public void user_selects_gender() throws Throwable {
	       
	    }

	    @And("^User unselects City $")
	    public void user_unselects_city() throws Throwable {
	       
	    }

	    @And("^User selects City $")
	    public void user_selects_city() throws Throwable {
	       
	    }

	    @And("^User unselects State$")
	    public void user_unselects_state() throws Throwable {
	       
	    }

	    @And("^User selects State $")
	    public void user_selects_state() throws Throwable {
	       
	    }

	    @And("^User leaves Subject Category empty$")
	    public void user_leaves_subject_category_empty() throws Throwable {
	       
	    }

	    @And("^User enters vaild Subject Category $")
	    public void user_enters_vaild_subject_category() throws Throwable {
	       
	    }

	    @And("^User leaves Paper Name empty$")
	    public void user_leaves_paper_name_empty() throws Throwable {
	       
	    }

	    @And("^User enters vaild Paper Name $")
	    public void user_enters_vaild_paper_name() throws Throwable {
	       
	    }

	    @And("^User leaves No of Author empty$")
	    public void user_leaves_no_of_author_empty() throws Throwable {
	       
	    }

	    @And("^User enters vaild No of Author $")
	    public void user_enters_vaild_no_of_author() throws Throwable {
	       
	    }

	    @And("^User leaves Company Name empty$")
	    public void user_leaves_company_name_empty() throws Throwable {
	       
	    }

	    @And("^User enters vaild Company Name $")
	    public void user_enters_vaild_company_name() throws Throwable {
	       
	    }

	    @And("^User leaves Designation empty$")
	    public void user_leaves_designation_empty() throws Throwable {
	       
	    }

	    @And("^User enters vaild Designation$")
	    public void user_enters_vaild_designation() throws Throwable {
	       
	    }
}
