$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("person.feature");
formatter.feature({
  "line": 3,
  "name": "Personal Information Application",
  "description": "",
  "id": "personal-information-application",
  "keyword": "Feature"
});
formatter.before({
  "duration": 10300957100,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Title of your scenario",
  "description": "",
  "id": "personal-information-application;title-of-your-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "Launch application browser",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "verify the title of the page opened",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "verify the heading of the page opened",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.launch_application_browser()"
});
formatter.result({
  "duration": 114160500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.verify_the_title_of_the_page_opened()"
});
formatter.result({
  "duration": 1015871800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.verify_the_heading_of_the_page_opened()"
});
formatter.result({
  "duration": 1091325800,
  "status": "passed"
});
formatter.after({
  "duration": 20638600,
  "status": "passed"
});
formatter.before({
  "duration": 10081559800,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Entering all the valid  fields in the form",
  "description": "",
  "id": "personal-information-application;entering-all-the-valid--fields-in-the-form",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "User is on the valid webpage",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "selects the Category",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "User enters Name of the applicant",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "User enters Firstname as on  PANCard",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "User enters Lastname  as on PANCard",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "User enters Fathername",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "User enters Date of Birth",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "User clicks on Reset",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "User enters Name of the applicant",
  "keyword": "Then "
});
formatter.step({
  "line": 23,
  "name": "User enters Firstname as on  PANCard",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "User enters Lastname  as on PANCard",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "User enters Fathername",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "User enters Date of Birth",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "User enters Gender is selected",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "User enters MobileNumber is given",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "User enters EmailID",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "User enters LandLine",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "User enters selects Communication",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "User enters gives Residence Address",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "User Clicks on Submit",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_valid_webpage()"
});
formatter.result({
  "duration": 1105234300,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.selects_the_category()"
});
formatter.result({
  "duration": 1122531200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_name_of_the_applicant()"
});
formatter.result({
  "duration": 1090130600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_firstname_as_on_pancard()"
});
formatter.result({
  "duration": 1089800200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_lastname_as_on_pancard()"
});
formatter.result({
  "duration": 1091220400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_fathername()"
});
formatter.result({
  "duration": 1091616700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_date_of_birth()"
});
formatter.result({
  "duration": 1096254600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_clicks_on_reset()"
});
formatter.result({
  "duration": 1122518800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_name_of_the_applicant()"
});
formatter.result({
  "duration": 1075714000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_firstname_as_on_pancard()"
});
formatter.result({
  "duration": 1075763300,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_lastname_as_on_pancard()"
});
formatter.result({
  "duration": 1075872600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_fathername()"
});
formatter.result({
  "duration": 1075777400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_date_of_birth()"
});
formatter.result({
  "duration": 1060513900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_gender_is_selected()"
});
formatter.result({
  "duration": 1120063600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_mobilenumber_is_given()"
});
formatter.result({
  "duration": 1091259700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_emailid()"
});
formatter.result({
  "duration": 1091210400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_landline()"
});
formatter.result({
  "duration": 1091410900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_selects_communication()"
});
formatter.result({
  "duration": 1122784000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_gives_residence_address()"
});
formatter.result({
  "duration": 1108076500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_clicks_on_submit()"
});
formatter.result({
  "duration": 1145006600,
  "status": "passed"
});
formatter.after({
  "duration": 64178800,
  "error_message": "org.openqa.selenium.UnhandledAlertException: Unexpected modal dialog (text: Please select the Gender): Please select the Gender\nBuild info: version: \u00272.53.0\u0027, revision: \u002735ae25b1534ae328c771e0856c93e187490ca824\u0027, time: \u00272016-03-15 10:43:46\u0027\nSystem info: host: \u0027din66007278\u0027, ip: \u002710.109.2.102\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_121\u0027\nDriver info: org.openqa.selenium.firefox.FirefoxDriver\nCapabilities [{applicationCacheEnabled\u003dtrue, rotatable\u003dfalse, handlesAlerts\u003dtrue, databaseEnabled\u003dtrue, version\u003d37.0, platform\u003dWINDOWS, nativeEvents\u003dfalse, acceptSslCerts\u003dtrue, webStorageEnabled\u003dtrue, locationContextEnabled\u003dtrue, browserName\u003dfirefox, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue}]\nSession ID: 73436ea2-f59b-44ed-98ed-fa1573cc7cd9\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:206)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createUnhandledAlertException(ErrorHandler.java:187)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:154)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:678)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:701)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.close(RemoteWebDriver.java:521)\r\n\tat stepDefinitions.StepDefinition.after(StepDefinition.java:389)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:40)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:34)\r\n\tat cucumber.runtime.java.JavaHookDefinition.execute(JavaHookDefinition.java:60)\r\n\tat cucumber.runtime.Runtime.runHookIfTagsMatch(Runtime.java:224)\r\n\tat cucumber.runtime.Runtime.runHooks(Runtime.java:212)\r\n\tat cucumber.runtime.Runtime.runAfterHooks(Runtime.java:206)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:46)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:102)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:95)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:38)\r\n\tat org.junit.runners.ParentRunner$3.run(ParentRunner.java:290)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:71)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:288)\r\n\tat org.junit.runners.ParentRunner.access$000(ParentRunner.java:58)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:268)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:363)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:100)\r\n\tat org.eclipse.jdt.internal.junit4.runner.JUnit4TestReference.run(JUnit4TestReference.java:86)\r\n\tat org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:38)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:538)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:760)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:460)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:206)\r\n",
  "status": "failed"
});
