package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration {

WebDriver driver;

	public Registration(WebDriver driver) {
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}

	@FindBy(xpath="//td")
	@CacheLookup 
    WebElement heading;
	
	@FindBy(xpath="//title")
	@CacheLookup 
    WebElement title;
	
	@FindBy(id="rdbCategory")
	@CacheLookup 
    WebElement ApplicantCat;
	
	@FindBy(id="txtName")
	@CacheLookup 
    WebElement Name;
	
	@FindBy(id="txtFirstName")
	@CacheLookup 
    WebElement firstname;
	
	@FindBy(id="txtLastName")
	@CacheLookup 
    WebElement lastname;
	
	@FindBy(id="rdbResAddress")
	@CacheLookup 
    WebElement communication;
	
	@FindBy(id="txtEmail")
	@CacheLookup 
    WebElement EmailId;
	
	@FindBy(id="txtFatherName")
	@CacheLookup 
    WebElement fathersname;
	
	@FindBy(id="btnReset")
	@CacheLookup 
    WebElement reset;
	
	@FindBy(xpath="//*[@class='auto-style11']")
	@CacheLookup 
    WebElement Gender;
	
	
	@FindBy(id="txtDOB")
	@CacheLookup 
    WebElement DOB;
	
	@FindBy(id="txtMobileNo")
	@CacheLookup 
    WebElement MobileNo;
	
	@FindBy(id="txtEmail")
	@CacheLookup 
    WebElement Email;
	
	@FindBy(id="txtLndLine")
	@CacheLookup 
    WebElement Landline;
	
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup 
    WebElement address;
	
	@FindBy(id="btnSubmit")
	@CacheLookup 
    WebElement submitbutton;
	
	@FindBy(xpath="html/body/h1")
	@CacheLookup 
    WebElement result;

	public WebElement Heading() {
		
		return heading;
	}

	public WebElement Category() {
		
		return ApplicantCat;
	}

	public WebElement LoginButton() {
		
		return submitbutton;
	}

	public WebElement Name() {
		
		return Name;
	}

	public WebElement FirstName() {
		
		return firstname;
	}

	public WebElement FathersName() {
		
		return fathersname;
	}

	public WebElement DOB() {
		
		return DOB;
	}

	public WebElement Gender() {
		
		return Gender;
	}

	public WebElement MobileNo() {
		
		return MobileNo;
	}

	public WebElement EmailID() {
		
		return EmailId;
	}

	public WebElement LandLine() {
		
		return Landline;
	}

	public WebElement Communication() {
		
		return communication;
	}

	public WebElement Residence() {
		
		return address;
	}

	public WebElement LastName() {
		
		return lastname;
	}

	public WebElement title() {
		
		return title;
	}

	public WebElement reset() {
		
		return reset;
	}
}
