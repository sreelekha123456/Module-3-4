package stepDefinitions;

import java.util.concurrent.TimeUnit;


import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pages.Registration;

import pages.SuccesPage;

public class StepDefinition {
	WebDriver driver=new FirefoxDriver();
	Registration reg;
	SuccesPage suc;
	
	@Before
    public void before()
    {
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 driver.get("file:///C:/Users/learning/Desktop/html/UserInformation.html");
		reg = new Registration(driver);
		suc = new SuccesPage(driver);
		
	
    }
	 @Given("^Launch application browser$")
	    public void launch_application_browser() throws Throwable {
	
		 System.out.println("launch application");
	    }
		@And("^verify the heading of the page opened$")
	    public void verify_the_heading_of_the_page_opened() throws Throwable {
	    	String actual = reg.Heading().getText();
	        String expected = "PERSONAL INFORMATION";
	        Assert.assertEquals(expected, actual);
	        Thread.sleep(1000);
	    }

		@Then("^verify the title of the page opened$")
	    public void verify_the_title_of_the_page_opened() throws Throwable {
			String actual = driver.getTitle();
	        String expected = "PAN CARD: User Information";
	        Assert.assertEquals(expected, actual);
	        Thread.sleep(1000);
	    }

	    
		
	    @Given("^User is on the valid webpage$")
	    public void user_is_on_the_valid_webpage() throws Throwable {
	    	String actual = reg.Heading().getText();
	        String expected = "PERSONAL INFORMATION";
	        Assert.assertEquals(expected, actual);
	        Thread.sleep(1000);
	      
	    }

	  

	    @When("^selects the Category$")
	    public void selects_the_category() throws Throwable {
	    	reg.Category().click();
	    	Thread.sleep(1000);
	    }

	    @When("^does not selects the Category and submits$")
	    public void does_not_selects_the_category_and_submits() throws Throwable {
	    	//reg.Category().click();
	    }

	    

	    @Then("^User Clicks on Submit$")
	    public void user_clicks_on_submit() throws Throwable {
	    	reg.LoginButton().click();
	    	Thread.sleep(1000);
	    }

	    @Then("^displays Please select Category$")
	    public void displays_please_select_category() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please select Category";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();
	    }

	    @Then("^displays Please enters Applicant Name$")
	    public void displays_please_enters_applicant_name() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the Full Name";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	    }

	    @Then("^displays Please enter firstname$")
	    public void displays_please_enter_firstname() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the First Name";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	    }
	    
	    @And("^User clicks on Reset$")
	    public void user_clicks_on_reset() throws Throwable {
	        reg.reset().click();
	        Thread.sleep(1000);
	    }

	    @Then("^displays Please enter lastname$")
	    public void displays_please_enter_lastname() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the Last Name";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	    }

	    @Then("^displays Please enter Fathername$")
	    public void displays_please_enter_fathername() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the Fathers Name";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	    }

	    @Then("^displays Please enter dob$")
	    public void displays_please_enter_dob() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the DOB";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	      
	    }

	    @Then("^displays Please select gender$")
	    public void displays_please_select_gender() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please select Gender";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	      
	    }

	    @Then("^displays Please enter mobile number$")
	    public void displays_please_enter_mobile_number() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the Mobile Number";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	    }

	    @Then("^displays Please enter emailID$")
	    public void displays_please_enter_emailid() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the Email ID";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	      
	    }

	    @Then("^displays Please enter Landline$")
	    public void displays_please_enter_landline() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the LandLine";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	      
	    }

	    @Then("^displays Please select communication$")
	    public void displays_please_select_communication() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please select communication";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	      
	    }

	    @Then("^displays Please enter Residence address$")
	    public void displays_please_enter_residence_address() throws Throwable {
	    	Alert promptAlert = driver.switchTo().alert();
	    	String expected = "Please fill the Residence Address";
	    	String actual = promptAlert.getText();
	    	Assert.assertEquals(expected, actual);
	    	Thread.sleep(1000);
	    	promptAlert.accept();

	      
	    }

	    @Then("^Display success message$")
	    public void display_success_message() throws Throwable {
	      
	    }

	    @And("^User enters Name of the applicant$")
	    public void user_enters_name_of_the_applicant() throws Throwable {
	    	reg.Name().sendKeys("Pannem");
	    	Thread.sleep(1000);
	      
	    }
	    
	    @Then("^User enters Name of the applicant1$")
	    public void user_enters_name_of_the_applicant1() throws Throwable {
	    	reg.Name().sendKeys("Pannem");
	    	Thread.sleep(1000);
	      
	    }

	    @And("^User enters Firstname as on  PANCard$")
	    public void user_enters_firstname_as_on_pancard() throws Throwable {
	    	reg.FirstName().sendKeys("Swathi");
	    	Thread.sleep(1000);
	    }

	    @And("^User enters Lastname  as on PANCard$")
	    public void user_enters_lastname_as_on_pancard() throws Throwable {
	    	reg.LastName().sendKeys("Sai roopa");
	    	Thread.sleep(1000);
	    }

	    @And("^User enters Fathername$")
	    public void user_enters_fathername() throws Throwable {
	    	reg.FathersName().sendKeys("venu");
	    	Thread.sleep(1000);
	    }
	    
	    

	    @And("^User enters Date of Birth$")
	    public void user_enters_date_of_birth() throws Throwable {
	    	reg.DOB().sendKeys("10-10-2010");
	    	Thread.sleep(1000);
	    }

	    @And("^User enters Gender is selected$")
	    public void user_enters_gender_is_selected() throws Throwable {
	    	reg.Gender().click();
	    	Thread.sleep(1000);
	    }

	    @And("^User enters MobileNumber is given$")
	    public void user_enters_mobilenumber_is_given() throws Throwable {
	    	reg.MobileNo().sendKeys("9087654321"); 
	    	Thread.sleep(1000);
	    }

	    @And("^User enters EmailID$")
	    public void user_enters_emailid() throws Throwable {
	    	reg.EmailID().sendKeys("swa@gmail.com");
	    	Thread.sleep(1000);
	    }

	    @And("^User enters LandLine$")
	    public void user_enters_landline() throws Throwable {
	    	reg.LandLine().sendKeys("023456");
	    	Thread.sleep(1000);
	    }

	    @And("^User enters selects Communication$")
	    public void user_enters_selects_communication() throws Throwable {
	    	reg.Communication().click();
	    	Thread.sleep(1000);
	    }

	    @And("^User enters gives Residence Address$")
	    public void user_enters_gives_residence_address() throws Throwable {
	    	reg.Residence().sendKeys("Gowlidodi"); 
	    	Thread.sleep(1000);
	    }

	  /*  @Then("^verifies the result page$")
	    public void verifies_the_result_page() throws Throwable {
	    	String actual = suc.PageContent().getText();
	        String expected = "PAN Card: User information saved successfully, Now next step is to make payment";
	        Assert.assertEquals(expected, actual);
	        Thread.sleep(1000);
	    }*/

	    @And("^not giving Name of the applicant and clicks on submit$")
	    public void not_giving_name_of_the_applicant_and_clicks_on_submit() throws Throwable {
	    	reg.Name().sendKeys("");
	    }

	    @And("^no firstname and clicks submit$")
	    public void no_firstname_and_clicks_submit() throws Throwable {
	    	reg.FirstName().sendKeys("");
	      
	    }

	    @And("^without lastname and submits$")
	    public void without_lastname_and_submits() throws Throwable {
	    	reg.FirstName().sendKeys("");
	    }

	    @And("^Fathersname notgiven and submits$")
	    public void fathersname_notgiven_and_submits() throws Throwable {
	    	reg.FathersName().sendKeys("");
	    }

	    @And("^Date of Birth and submits$")
	    public void date_of_birth_and_submits() throws Throwable {
	    	reg.DOB().sendKeys("");
	    }

	    @And("^Gender is not selected and submits$")
	    public void gender_is_not_selected_and_submits() throws Throwable {
	    	reg.Gender().click();
	    }

	    @And("^MobileNumber is not given and submits$")
	    public void mobilenumber_is_not_given_and_submits() throws Throwable {
	    	reg.MobileNo().sendKeys("");
	    }

	    @And("^EmailID is not given and submits$")
	    public void emailid_is_not_given_and_submits() throws Throwable {
	    	reg.EmailID().sendKeys("");
	    }

	    @And("^LandLine is not given and submits$")
	    public void landline_is_not_given_and_submits() throws Throwable {
	    	reg.LandLine().sendKeys("");
	    }

	    @And("^Communication is not selected and submits$")
	    public void communication_is_not_selected_and_submits() throws Throwable {
	    	reg.Communication().click();
	    }

	    @And("^Residence Address is not given and submits$")
	    public void residence_address_is_not_given_and_submits() throws Throwable {
	    	reg.Residence().sendKeys("");
	    }

	    
	    @And("^Clicks on Submit button$")
	    public void clicks_on_submit_button() throws Throwable {
	    	reg.LoginButton().click();
	    	Thread.sleep(1000);
	    }
	    @After
	    public void after()
	    {
	    	driver.close();
	    }
}
