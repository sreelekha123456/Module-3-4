package objectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPOF 
{
	WebDriver driver;
	public LoginPOF(WebDriver driver)                                   
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath=".//*[@id='mainCnt']/div/div/form/h3/a")
	@CacheLookup 
    WebElement heading;
	
	@FindBy(xpath="html/body/p/a")
	@CacheLookup 
    WebElement back;
	
	@FindBy(name="userName")
	@CacheLookup 
    WebElement uname;                          //create webelement variable for username  
	
	@FindBy(name="userPwd")
	@CacheLookup 
    WebElement upwd;
	
	@FindBy(className="btn")
	@CacheLookup 
    WebElement login;
	
	@FindBy(xpath=".//*[@id='userErrMsg']")
	@CacheLookup 
    WebElement errmsguser;
	
	@FindBy(xpath=".//*[@id='pwdErrMsg']")
	@CacheLookup 
    WebElement errmsgpwd;
	
	
	public WebElement Heading()       //create method for webelement 
	{
		return heading;                               //returning webelement from findby
	}
	
	public WebElement Navigationback()
	{
		return back;
	}
	
	public WebElement UserName()
	{
		return uname;
	}
	
	public WebElement UserPassword()
	{
		return upwd;
	}
	
	public WebElement UserErrorMsg()
	{
		return errmsguser;
	}
	
	public WebElement PasswordErrorMsg()
	{
		return errmsgpwd;
	}
}
