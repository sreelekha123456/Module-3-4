package stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import objectRepository.LoginPOF;

public class jousteps
{
	
	
	WebDriver driver;
	LoginPOF log;
	
	
     //***********************************************************************************//	 
	@Before
    public void before() 
	{
    WebDriver driver = new FirefoxDriver();
    driver.get("file:///C:/Ajournelwebpages/login.html");
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
   
        log = new LoginPOF(driver);
	}
	
	//*********************************************************************************//
	
	 @Given("^User is on valid Login page$")
	    public void user_is_on_valid_login_page() throws Throwable
	 {
			driver.get("C:\\\\Ajournelwebpages\\\\login.html");
	        String actual = log.Heading().getText();
	        String expected = "Paper Submission for International Journal";
	        Assert.assertEquals(expected, actual);
			
	    }

	    @When("^User clicks on click here to know subject categories$")
	    public void user_clicks_on_click_here_to_know_subject_categories() throws Throwable {
	       
	    }

	    @When("^User leaves UserName Empty$")
	    public void user_leaves_username_empty() throws Throwable {
	       
	    }

	    @Then("^Subject Category page should be displayed$")
	    public void subject_category_page_should_be_displayed() throws Throwable {
	       
	    }

	    @Then("^Login page is displayed$")
	    public void login_page_is_displayed() throws Throwable {
	       
	    }

	    @Then("^Error message Please enter UserName displays$")
	    public void error_message_please_enter_username_displays() throws Throwable {
	       
	    }

	    @Then("^Error message Please enter Password displays$")
	    public void error_message_please_enter_password_displays() throws Throwable {
	       
	    }

	    @Then("^User is navigated to Registration  page$")
	    public void user_is_navigated_to_registration_page() throws Throwable {
	       
	    }

	    @And("^Clicks Back Link$")
	    public void clicks_back_link() throws Throwable {
	       
	    }

	    @And("^Clicks on Login button$")
	    public void clicks_on_login_button() throws Throwable {
	       
	    }

	    @And("^User enters valid UserName$")
	    public void user_enters_valid_username() throws Throwable {
	       
	    }

	    @And("^User leaves Password Empty$")
	    public void user_leaves_password_empty() throws Throwable {
	       
	    }

	    @And("^User enters valid Password$")
	    public void user_enters_valid_password() throws Throwable {
	       
	    }

}
