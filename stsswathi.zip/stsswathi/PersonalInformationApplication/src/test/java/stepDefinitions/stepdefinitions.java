package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageFactory.TitlePOF;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdefinitions {
	WebDriver driver=new FirefoxDriver();
	TitlePOF pof;
	
	@Given("^Launch the application browser$")
    public void launch_the_application_browser_firefox_google_chrome_ie() throws Throwable {
		pof= new TitlePOF(driver);
		driver.get("file:///C:/Users/learning/Desktop/html/UserInformation.html");
		System.out.println("Hello");
    }

    @When("^User opens the personal information website$")
    public void user_opens_the_personal_information_website() throws Throwable {
    	
    }

    @Then("^verify the title of the page opened$")
    public void verify_the_title_of_the_page_opened() throws Throwable {
    
    String actual = pof.title().getText();
    String expected = "PERSONAL INFORMATION";
    Assert.assertEquals(expected, actual);
    }

    @And("^check whether the title is matching the expected title$")
    public void check_whether_the_title_is_matching_the_expected_title() throws Throwable {
        
    }
	
	
    @Given("^User is on the valid webpage$")
    public void user_is_on_the_valid_webpage() throws Throwable {
    	pof= new TitlePOF(driver);
    	driver.get("file:///C:/Users/learning/Desktop/html/UserInformation.html");
    	 String actual = pof.title().getText();
    	    String expected = "PERSONAL INFORMATION";
    	    Assert.assertEquals(expected, actual);
    }

    @When("^selects the Category$")
    public void selects_the_category() throws Throwable {
        
    }

    @Then("^Clicks on Submit$")
    public void clicks_on_submit() throws Throwable {
        pof.submitbutton().click();
    }

    @And("^Name of the applicant$")
    public void name_of_the_applicant() throws Throwable {
        pof.Name().sendKeys("Pannem");
    }

    @And("^firstname as on  PANCard$")
    public void firstname_as_on_pancard() throws Throwable {
        pof.firstname().sendKeys("swathi");
    }

    @And("^lastname  as on PANCard$")
    public void lastname_as_on_pancard() throws Throwable {
        pof.lastname().sendKeys("sai roopa");
    }

    @And("^Fathersname$")
    public void fathersname() throws Throwable {
        pof.fathername().sendKeys("venu");
    }

    @And("^Date of Birth$")
    public void date_of_birth() throws Throwable {
        pof.DOB().sendKeys("10-10-2019");
    }

    @And("^Gender is selected$")
    public void gender_is_selected() throws Throwable {
        
    }

    @And("^MobileNumber is given$")
    public void mobilenumber_is_given() throws Throwable {
        pof.MobileNo().sendKeys("9087654321");
    }

    @And("^EmailID$")
    public void emailid() throws Throwable {
        pof.Email().sendKeys("swa@gmail.com");
    }

    @And("^LandLine$")
    public void landline() throws Throwable {
        pof.Landline().sendKeys("0201289201");
    }

    @And("^selects Communication$")
    public void selects_communication() throws Throwable {
        
    }

    @And("^gives Residence Address$")
    public void gives_residence_address() throws Throwable {
        pof.address().sendKeys("Capgemini,Finacial district");
    }

    @And("^verifies the result page$")
    public void verifies_the_result_page() throws Throwable {
    	String actual = pof.result().getText();
	    String expected = "PAN Card: User information saved successfully, Now next step is to make payment";
	    Assert.assertEquals(expected, actual);
    }
	
    @Given("^valid webpage$")
    public void valid_webpage() throws Throwable {
        
    }

    @When("^does not selects the Category and submits$")
    public void does_not_selects_the_category_and_submits() throws Throwable {
        
    }

    @Then("^displays error message$")
    public void displays_error_message() throws Throwable {
        
    }

    @Then("^Clicks on Submit displays error message$")
    public void clicks_on_submit_displays_error_message() throws Throwable {
        
    }

    @And("^not giving Name of the applicant and clicks on submit$")
    public void not_giving_name_of_the_applicant_and_clicks_on_submit() throws Throwable {
        
    }

    @And("^no firstname and clicks submit$")
    public void no_firstname_and_clicks_submit() throws Throwable {
        
    }

    @And("^without lastname and submits$")
    public void without_lastname_and_submits() throws Throwable {
        
    }

    @And("^Fathersname notgiven and submits$")
    public void fathersname_notgiven_and_submits() throws Throwable {
        
    }

    @And("^Date of Birth and submits$")
    public void date_of_birth_and_submits() throws Throwable {
        
    }

    @And("^Gender is not selected and submits$")
    public void gender_is_not_selected_and_submits() throws Throwable {
        
    }

    @And("^MobileNumber is not given and submits$")
    public void mobilenumber_is_not_given_and_submits() throws Throwable {
        
    }

    @And("^EmailID is not given and submits$")
    public void emailid_is_not_given_and_submits() throws Throwable {
        
    }

    @And("^LandLine is not given and submits$")
    public void landline_is_not_given_and_submits() throws Throwable {
        
    }

    @And("^Communication is not selected and submits$")
    public void communication_is_not_selected_and_submits() throws Throwable {
        
    }

    @And("^Residence Address is not given$")
    public void residence_address_is_not_given() throws Throwable {
        
    }

    @And("^verifies the error messages$")
    public void verifies_the_error_messages() throws Throwable {
        
    }
}
