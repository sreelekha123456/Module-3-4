package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TitlePOF {
	WebDriver driver;
	public TitlePOF(WebDriver driver)
	{
		this.driver =driver;
        PageFactory.initElements(driver,this);
	}
	
	
	@FindBy(xpath="html/body/form/table/tbody/tr[1]/td")
	@CacheLookup 
    WebElement title;
	
	@FindBy(id="rdbCategory")
	@CacheLookup 
    WebElement ApplicantCat;
	@FindBy(id="txtName")
	@CacheLookup 
    WebElement Name;
	@FindBy(id="txtFirstName")
	@CacheLookup 
    WebElement firstname;
	
	@FindBy(id="txtLastName")
	@CacheLookup 
    WebElement lastname;
	@FindBy(id="txtFatherName")
	@CacheLookup 
    WebElement fathername;
	
	@FindBy(id="txtDOB")
	@CacheLookup 
    WebElement DOB;
	@FindBy(id="txtMobileNo")
	@CacheLookup 
    WebElement MobileNo;
	@FindBy(id="txtEmail")
	@CacheLookup 
    WebElement Email;
	@FindBy(id="txtLndLine")
	@CacheLookup 
    WebElement Landline;
	
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup 
    WebElement address;
	
	@FindBy(id="btnSubmit")
	@CacheLookup 
    WebElement submitbutton;
	@FindBy(xpath="html/body/h1")
	@CacheLookup 
    WebElement result;
	
	public WebElement title()
	{
		return title;
	}

	public WebElement ApplicantCat()
	{
		return ApplicantCat;
	}

	
	public WebElement Name()
	{
		return Name;
	}
	
	public WebElement firstname()
	{
		return firstname;
	}
	
	public WebElement lastname()
	{
		return lastname;
	}
	
	public WebElement fathername()
	{
		return fathername;
	}
	
	public WebElement DOB()
	{
		return DOB;
	}
	public WebElement MobileNo()
	{
		return MobileNo;
	}
	public WebElement Email()
	{
		return Email;
	}
	public WebElement Landline()
	{
		return Landline;
	}
	public WebElement address()
	{
		return address;
	}
	public WebElement submitbutton()
	{
		return submitbutton;
	}
	public WebElement result()
	{
		return result;
	}
}
