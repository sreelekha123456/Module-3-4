$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("person.feature");
formatter.feature({
  "line": 1,
  "name": "Personal Information Application",
  "description": "",
  "id": "personal-information-application",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Title of your scenario",
  "description": "",
  "id": "personal-information-application;title-of-your-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "Launch the application browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User opens the personal information website",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "verify the title of the page opened",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "check whether the title is matching the expected title",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.launch_the_application_browser_firefox_google_chrome_ie()"
});
formatter.result({
  "duration": 6540287300,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.user_opens_the_personal_information_website()"
});
formatter.result({
  "duration": 20200,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.verify_the_title_of_the_page_opened()"
});
formatter.result({
  "duration": 102041100,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.check_whether_the_title_is_matching_the_expected_title()"
});
formatter.result({
  "duration": 21700,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Entering all the valid  fields in the form",
  "description": "",
  "id": "personal-information-application;entering-all-the-valid--fields-in-the-form",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "User is on the valid webpage",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "selects the Category",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Name of the applicant",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "firstname as on  PANCard",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "lastname  as on PANCard",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Fathersname",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "Date of Birth",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "Gender is selected",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "MobileNumber is given",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "EmailID",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "LandLine",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "selects Communication",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "gives Residence Address",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "Clicks on Submit",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "verifies the result page",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.user_is_on_the_valid_webpage()"
});
formatter.result({
  "duration": 5115309400,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.selects_the_category()"
});
formatter.result({
  "duration": 22700,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.name_of_the_applicant()"
});
formatter.result({
  "duration": 59604600,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.firstname_as_on_pancard()"
});
formatter.result({
  "duration": 59844700,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.lastname_as_on_pancard()"
});
formatter.result({
  "duration": 627456200,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.fathersname()"
});
formatter.result({
  "duration": 55087700,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.date_of_birth()"
});
formatter.result({
  "duration": 48189000,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.gender_is_selected()"
});
formatter.result({
  "duration": 20800,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.mobilenumber_is_given()"
});
formatter.result({
  "duration": 76565700,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.emailid()"
});
formatter.result({
  "duration": 65490100,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.landline()"
});
formatter.result({
  "duration": 56118800,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.selects_communication()"
});
formatter.result({
  "duration": 21500,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.gives_residence_address()"
});
formatter.result({
  "duration": 87460700,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.clicks_on_submit()"
});
formatter.result({
  "duration": 115890500,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.verifies_the_result_page()"
});
formatter.result({
  "duration": 62793800,
  "error_message": "org.openqa.selenium.UnhandledAlertException: Unexpected modal dialog (text: Please select the Gender): Please select the Gender\nBuild info: version: \u00272.53.0\u0027, revision: \u002735ae25b1534ae328c771e0856c93e187490ca824\u0027, time: \u00272016-03-15 10:43:46\u0027\nSystem info: host: \u0027din66007278\u0027, ip: \u002710.109.2.102\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_121\u0027\nDriver info: org.openqa.selenium.firefox.FirefoxDriver\nCapabilities [{applicationCacheEnabled\u003dtrue, rotatable\u003dfalse, handlesAlerts\u003dtrue, databaseEnabled\u003dtrue, version\u003d37.0, platform\u003dWINDOWS, nativeEvents\u003dfalse, acceptSslCerts\u003dtrue, webStorageEnabled\u003dtrue, locationContextEnabled\u003dtrue, browserName\u003dfirefox, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue}]\nSession ID: 20b3b862-42e9-41f6-ba5c-d29284b34422\n*** Element info: {Using\u003dxpath, value\u003dhtml/body/h1}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:206)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createUnhandledAlertException(ErrorHandler.java:187)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:154)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:678)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:363)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:500)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:361)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:355)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy16.getText(Unknown Source)\r\n\tat stepDefinitions.stepdefinitions.verifies_the_result_page(stepdefinitions.java:119)\r\n\tat ✽.And verifies the result page(person.feature:25)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 27,
  "name": "Validating all the fields in the form",
  "description": "",
  "id": "personal-information-application;validating-all-the-fields-in-the-form",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "valid webpage",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "does not selects the Category and submits",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "displays error message",
  "keyword": "Then "
});
formatter.step({
  "line": 31,
  "name": "not giving Name of the applicant and clicks on submit",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "no firstname and clicks submit",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "without lastname and submits",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "Fathersname notgiven and submits",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "Date of Birth and submits",
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "Gender is not selected and submits",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "MobileNumber is not given and submits",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "EmailID is not given and submits",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "LandLine is not given and submits",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "Communication is not selected and submits",
  "keyword": "And "
});
formatter.step({
  "line": 43,
  "name": "Residence Address is not given",
  "keyword": "And "
});
formatter.step({
  "line": 44,
  "name": "Clicks on Submit displays error message",
  "keyword": "Then "
});
formatter.step({
  "line": 45,
  "name": "verifies the error messages",
  "keyword": "And "
});
formatter.match({
  "location": "stepdefinitions.valid_webpage()"
});
formatter.result({
  "duration": 5603249400,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.does_not_selects_the_category_and_submits()"
});
formatter.result({
  "duration": 21500,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.displays_error_message()"
});
formatter.result({
  "duration": 18100,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.not_giving_name_of_the_applicant_and_clicks_on_submit()"
});
formatter.result({
  "duration": 19900,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.no_firstname_and_clicks_submit()"
});
formatter.result({
  "duration": 11700,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.without_lastname_and_submits()"
});
formatter.result({
  "duration": 13000,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.fathersname_notgiven_and_submits()"
});
formatter.result({
  "duration": 29300,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.date_of_birth_and_submits()"
});
formatter.result({
  "duration": 12500,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.gender_is_not_selected_and_submits()"
});
formatter.result({
  "duration": 12900,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.mobilenumber_is_not_given_and_submits()"
});
formatter.result({
  "duration": 13700,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.emailid_is_not_given_and_submits()"
});
formatter.result({
  "duration": 12600,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.landline_is_not_given_and_submits()"
});
formatter.result({
  "duration": 12000,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.communication_is_not_selected_and_submits()"
});
formatter.result({
  "duration": 12300,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.residence_address_is_not_given()"
});
formatter.result({
  "duration": 18200,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.clicks_on_submit_displays_error_message()"
});
formatter.result({
  "duration": 14900,
  "status": "passed"
});
formatter.match({
  "location": "stepdefinitions.verifies_the_error_messages()"
});
formatter.result({
  "duration": 22500,
  "status": "passed"
});
});